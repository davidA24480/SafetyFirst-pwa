# SafetyFirst.AI - Adding More WHS Regulations

## Current Database Status
- **Current chunks:** 506
- **Documents:** 8 WHS regulation sources
- **Coverage:** Basic Australian WHS regulations

## How to Add More Regulations

### Method 1: Using the Python Script (Recommended)

1. **Prepare Your Documents**
   - Download WHS regulations as PDF or text files
   - Save to a folder (e.g., `/regulations`)

2. **Run the Processor Script**
   ```bash
   python3 safetyfirst_simple.py
   ```

3. **The Script Will:**
   - Read all PDF/text files in the directory
   - Split into 500-character chunks
   - Generate OpenAI embeddings
   - Upload to Supabase with metadata

### Method 2: Manual Upload

**Database Schema:**
```sql
-- Insert a new document
INSERT INTO documents (title, source_type, jurisdiction, source_url, is_current)
VALUES (
    'Work Health and Safety Regulation 2024',
    'regulation',
    'Commonwealth',
    'https://www.legislation.gov.au/...',
    true
);

-- Get the document_id
-- Then insert chunks:
INSERT INTO document_chunks (
    document_id,
    content,
    chunk_index,
    regulation_number,
    section_title,
    part_chapter,
    embedding
)
VALUES (
    'uuid-here',
    'Regulation text here...',
    0,
    'Regulation 225',
    'Fall Protection',
    'Part 4.4',
    '[0.123, 0.456, ...]'::vector(1536)
);
```

## Recommended Regulations to Add

### Priority 1: Core WHS Regulations
- [ ] **Safe Work Australia Model WHS Regulations** (complete set)
- [ ] **State-specific regulations** for all states/territories:
  - NSW: Work Health and Safety Regulation 2017
  - VIC: Occupational Health and Safety Regulations 2017
  - QLD: Work Health and Safety Regulation 2011
  - SA: Work Health and Safety Regulations 2012
  - WA: Occupational Safety and Health Regulations 1996
  - TAS: Work Health and Safety Regulations 2012
  - NT: Work Health and Safety (National Uniform Legislation) Regulations 2011
  - ACT: Work Health and Safety Regulation 2011

### Priority 2: Codes of Practice
- [ ] Managing the risk of falls at workplaces
- [ ] Confined spaces
- [ ] Managing electrical risks
- [ ] Managing noise and preventing hearing loss
- [ ] First aid in the workplace
- [ ] Managing risks of hazardous chemicals
- [ ] Managing risks of plant
- [ ] Work health and safety consultation, cooperation and coordination

### Priority 3: Industry-Specific Guidance
- [ ] Construction industry guidelines
- [ ] Manufacturing safety standards
- [ ] Mining and resources sector
- [ ] Healthcare and aged care
- [ ] Transport and logistics

## Sources for Regulations

### Official Government Sources
1. **Safe Work Australia**
   - https://www.safeworkaustralia.gov.au/
   - Model WHS laws and codes of practice

2. **State/Territory Regulators**
   - SafeWork NSW: https://www.safework.nsw.gov.au/
   - WorkSafe Victoria: https://www.worksafe.vic.gov.au/
   - WorkSafe Queensland: https://www.worksafe.qld.gov.au/
   - SafeWork SA: https://www.safework.sa.gov.au/
   - WorkSafe WA: https://www.commerce.wa.gov.au/worksafe/
   - WorkSafe Tasmania: https://worksafe.tas.gov.au/
   - NT WorkSafe: https://worksafe.nt.gov.au/
   - WorkSafe ACT: https://www.worksafe.act.gov.au/

3. **Australian Legislation**
   - https://www.legislation.gov.au/

## Processing New Documents

### Step-by-Step Process

1. **Download the regulation PDF**
2. **Extract text** (script handles this)
3. **Chunk the text** (500 chars per chunk with 50 char overlap)
4. **Generate embeddings** via OpenAI API
5. **Upload to Supabase** with proper metadata

### Metadata Fields to Include
- `title`: Full document title
- `source_type`: 'regulation', 'code_of_practice', 'guidance', 'standard'
- `jurisdiction`: 'Commonwealth', 'NSW', 'VIC', 'QLD', etc.
- `source_url`: Link to official source
- `effective_date`: When regulation came into effect
- `is_current`: true/false (for version control)
- `regulation_number`: e.g., "Regulation 225"
- `section_title`: e.g., "Fall Protection Requirements"
- `part_chapter`: e.g., "Part 4.4"

## Quality Control

### After Adding New Regulations

1. **Test Queries**
   ```
   Test: "What are the requirements for confined spaces in Victoria?"
   Expected: Should return Victoria-specific regulations
   ```

2. **Check Coverage**
   ```sql
   -- Count chunks by jurisdiction
   SELECT d.jurisdiction, COUNT(dc.id) as chunk_count
   FROM documents d
   JOIN document_chunks dc ON d.id = dc.document_id
   GROUP BY d.jurisdiction;
   ```

3. **Verify Embeddings**
   ```sql
   -- Check that all chunks have embeddings
   SELECT COUNT(*) 
   FROM document_chunks 
   WHERE embedding IS NULL;
   -- Should return 0
   ```

## Estimated Costs

### OpenAI Embedding Costs
- **Model:** text-embedding-ada-002
- **Cost:** $0.0001 per 1K tokens
- **Average:** ~1 regulation PDF (50 pages) = 25,000 tokens = $0.0025
- **100 regulations:** ~$0.25

### Storage Costs (Supabase)
- **Vector storage:** ~1.5KB per chunk
- **10,000 chunks:** ~15MB
- **Cost:** Negligible (included in $25/month plan)

## Automation Ideas

### Auto-Update System
```python
# Pseudo-code for automated updates
def check_for_updates():
    # Scrape Safe Work Australia for new documents
    new_docs = scrape_swa_website()
    
    for doc in new_docs:
        if not exists_in_database(doc.url):
            download_and_process(doc)
            notify_admin("New regulation added: " + doc.title)
```

## Next Steps

1. **Immediate:** Add all Model WHS Codes of Practice (Priority 2)
2. **This Week:** Add state-specific regulations for NSW, VIC, QLD
3. **This Month:** Complete all jurisdictions
4. **Ongoing:** Set up automated checks for regulation updates

## Support Resources

- **Supabase Dashboard:** https://gpbncxphtouzgkbtbyst.supabase.co
- **OpenAI API:** https://platform.openai.com/
- **n8n Workflows:** https://safetyfirstai.app.n8n.cloud

---

**Current Database Connection:**
- Project: gpbncxphtouzgkbtbyst.supabase.co
- Service Key: sb_secret_JTNTgX97kQ4mDmciHRFShQ_IDqOwxmK
- OpenAI Key: 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
