# SafetyFirst.AI - Analytics Setup Guide

## Overview

Track usage, performance, and user behavior to improve SafetyFirst.AI and demonstrate ROI to potential customers.

## Analytics Architecture

```
┌──────────────────────────────────────────────────┐
│           DATA COLLECTION POINTS                  │
├──────────────────────────────────────────────────┤
│  • n8n workflow executions                        │
│  • Twilio message logs                            │
│  • ElevenLabs call logs                           │
│  • Web interface interactions                     │
│  • API response times                             │
└────────────────┬─────────────────────────────────┘
                 │
                 v
┌──────────────────────────────────────────────────┐
│         ANALYTICS DATABASE (Supabase)            │
│  • query_history table                            │
│  • usage_metrics table                            │
│  • error_logs table                               │
└────────────────┬─────────────────────────────────┘
                 │
                 v
┌──────────────────────────────────────────────────┐
│           VISUALIZATION & REPORTING               │
│  • Supabase Dashboard                            │
│  • Custom Analytics Page                          │
│  • Weekly Email Reports                           │
└──────────────────────────────────────────────────┘
```

## Step 1: Create Analytics Tables

Run this SQL in Supabase SQL Editor:

```sql
-- Query History Table
CREATE TABLE IF NOT EXISTS query_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    channel VARCHAR(20), -- 'sms', 'voice', 'web', 'whatsapp'
    user_phone VARCHAR(20), -- anonymized or hashed
    query_text TEXT,
    response_text TEXT,
    response_time_ms INTEGER,
    chunks_retrieved INTEGER,
    success BOOLEAN DEFAULT true,
    error_message TEXT
);

-- Usage Metrics Table
CREATE TABLE IF NOT EXISTS usage_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE DEFAULT CURRENT_DATE,
    channel VARCHAR(20),
    total_queries INTEGER DEFAULT 0,
    successful_queries INTEGER DEFAULT 0,
    failed_queries INTEGER DEFAULT 0,
    avg_response_time_ms INTEGER,
    unique_users INTEGER,
    total_cost_usd DECIMAL(10,4)
);

-- Error Logs Table
CREATE TABLE IF NOT EXISTS error_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    channel VARCHAR(20),
    error_type VARCHAR(50),
    error_message TEXT,
    stack_trace TEXT,
    user_context JSONB
);

-- Popular Topics Table
CREATE TABLE IF NOT EXISTS popular_topics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    topic VARCHAR(100),
    query_count INTEGER DEFAULT 0,
    last_queried TIMESTAMPTZ,
    example_queries TEXT[]
);

-- Create indexes for performance
CREATE INDEX idx_query_history_created ON query_history(created_at DESC);
CREATE INDEX idx_query_history_channel ON query_history(channel);
CREATE INDEX idx_usage_metrics_date ON usage_metrics(date DESC);
CREATE INDEX idx_error_logs_created ON error_logs(created_at DESC);
```

## Step 2: Add Logging to n8n Workflows

### Add to WHS Query API Workflow

After the "Ask Claude" node, add a **Supabase** node:

**Node Name:** Log Query to Analytics

**Configuration:**
- **Operation:** Insert
- **Table:** query_history
- **Fields:**
  - `channel`: `web` (or dynamic based on source)
  - `query_text`: `={{ $('HTTP Request').item.json.query }}`
  - `response_text`: `={{ $json.content[0].text }}`
  - `chunks_retrieved`: `={{ $('Search WHS Regulations').item.json.length }}`
  - `response_time_ms`: `={{ $workflow.timestamp - $node["HTTP Request"].startTime }}`
  - `success`: `true`

### Add to SMS/WhatsApp Workflow

After "Send SMS Reply", add similar Supabase logging:

**Fields:**
- `channel`: `sms`
- `user_phone`: `={{ $('Parse Message').item.json.from }}` (consider hashing for privacy)
- `query_text`: `={{ $('Parse Message').item.json.messageBody }}`
- `response_text`: `={{ $('Prepare Response').item.json.responseText }}`

## Step 3: Key Metrics to Track

### Usage Metrics
- **Total queries per day/week/month**
- **Queries by channel** (SMS vs Voice vs Web)
- **Unique users** (count distinct phone numbers)
- **Peak usage times**
- **Average queries per user**

### Performance Metrics
- **Average response time**
- **Success rate** (successful queries / total queries)
- **Error rate by type**
- **API latency** (OpenAI, Claude, Supabase)

### Content Metrics
- **Most common topics** (fall protection, confined spaces, PPE, etc.)
- **Regulation citation frequency** (which regs are most referenced)
- **Query complexity** (simple vs complex questions)
- **Photo analysis usage** (% of queries with photos)

### Cost Metrics
- **OpenAI embedding costs**
- **Claude API costs**
- **Twilio SMS/MMS costs**
- **ElevenLabs voice costs**
- **Cost per query**
- **Cost per channel**

## Step 4: Create Analytics Queries

Save these queries for regular reporting:

### Daily Summary
```sql
SELECT 
    channel,
    COUNT(*) as total_queries,
    COUNT(*) FILTER (WHERE success = true) as successful,
    COUNT(*) FILTER (WHERE success = false) as failed,
    AVG(response_time_ms) as avg_response_ms,
    COUNT(DISTINCT user_phone) as unique_users
FROM query_history
WHERE created_at >= CURRENT_DATE
GROUP BY channel
ORDER BY total_queries DESC;
```

### Weekly Trends
```sql
SELECT 
    DATE_TRUNC('day', created_at) as day,
    COUNT(*) as queries,
    AVG(response_time_ms) as avg_response_time
FROM query_history
WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY DATE_TRUNC('day', created_at)
ORDER BY day;
```

### Top 10 Topics
```sql
SELECT 
    LOWER(LEFT(query_text, 50)) as query_preview,
    COUNT(*) as frequency
FROM query_history
WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY LOWER(LEFT(query_text, 50))
ORDER BY frequency DESC
LIMIT 10;
```

### Error Analysis
```sql
SELECT 
    error_type,
    COUNT(*) as error_count,
    MAX(created_at) as last_occurrence
FROM error_logs
WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY error_type
ORDER BY error_count DESC;
```

### Cost Analysis
```sql
-- Estimate costs (you'll need to add cost tracking)
SELECT 
    DATE_TRUNC('day', created_at) as day,
    channel,
    COUNT(*) as queries,
    -- OpenAI: ~$0.0001 per query
    COUNT(*) * 0.0001 as openai_cost,
    -- Claude: ~$0.003 per query (estimated)
    COUNT(*) * 0.003 as claude_cost,
    -- Twilio SMS: ~$0.0075 per message
    COUNT(*) FILTER (WHERE channel = 'sms') * 0.0075 as twilio_cost,
    -- Total estimated cost
    (COUNT(*) * 0.0001) + (COUNT(*) * 0.003) + (COUNT(*) FILTER (WHERE channel = 'sms') * 0.0075) as total_cost
FROM query_history
WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY DATE_TRUNC('day', created_at), channel
ORDER BY day DESC;
```

## Step 5: Build Analytics Dashboard

### Option 1: Supabase Built-in Analytics
- Use Supabase's Table View with filters
- Create saved views for common queries
- Export to CSV for external analysis

### Option 2: Custom Web Dashboard

Create a simple HTML dashboard:

```html
<!DOCTYPE html>
<html>
<head>
    <title>SafetyFirst.AI Analytics</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <h1>SafetyFirst.AI Analytics Dashboard</h1>
    
    <div class="metrics">
        <div class="metric-card">
            <h3>Total Queries Today</h3>
            <p id="total-queries">Loading...</p>
        </div>
        <div class="metric-card">
            <h3>Success Rate</h3>
            <p id="success-rate">Loading...</p>
        </div>
        <div class="metric-card">
            <h3>Avg Response Time</h3>
            <p id="avg-response-time">Loading...</p>
        </div>
    </div>
    
    <canvas id="usage-chart"></canvas>
    
    <script>
        // Fetch from Supabase and display
        // Implementation depends on your preference
    </script>
</body>
</html>
```

### Option 3: Google Sheets Integration

Export data daily to Google Sheets for easy visualization:
- Create a scheduled n8n workflow
- Query Supabase analytics tables
- Push to Google Sheets API
- Use Sheets charts for visualization

## Step 6: Set Up Alerts

Create automated alerts for important events:

### Critical Errors Alert
```sql
-- If errors > 10 in last hour, send alert
SELECT COUNT(*) as error_count
FROM error_logs
WHERE created_at >= NOW() - INTERVAL '1 hour'
HAVING COUNT(*) > 10;
```

### High Usage Alert
```sql
-- If queries > 1000 today, send notification
SELECT COUNT(*) as query_count
FROM query_history
WHERE created_at >= CURRENT_DATE
HAVING COUNT(*) > 1000;
```

### Cost Threshold Alert
```sql
-- If estimated daily cost > $50
SELECT SUM(estimated_cost) as total_cost
FROM usage_metrics
WHERE date = CURRENT_DATE
HAVING SUM(estimated_cost) > 50;
```

## Step 7: Privacy & Compliance

### Data Anonymization
```sql
-- Hash phone numbers for privacy
CREATE OR REPLACE FUNCTION hash_phone(phone TEXT)
RETURNS TEXT AS $$
BEGIN
    RETURN encode(digest(phone || 'your-secret-salt', 'sha256'), 'hex');
END;
$$ LANGUAGE plpgsql;

-- Use when logging:
INSERT INTO query_history (user_phone, ...)
VALUES (hash_phone('+61433601593'), ...);
```

### Data Retention
```sql
-- Delete logs older than 90 days
DELETE FROM query_history
WHERE created_at < NOW() - INTERVAL '90 days';

-- Schedule this to run weekly
```

## Step 8: Reporting

### Weekly Email Report Template

```
📊 SafetyFirst.AI Weekly Report
Week of: [Date]

📈 USAGE STATS
• Total Queries: 1,234 (+15% vs last week)
• Unique Users: 456
• Success Rate: 98.5%
• Avg Response Time: 1.2s

📱 BY CHANNEL
• SMS: 850 queries (69%)
• Web: 300 queries (24%)
• Voice: 84 queries (7%)

🔥 TOP TOPICS
1. Fall protection requirements (234 queries)
2. Confined space entry (189 queries)
3. PPE requirements (156 queries)

💰 COSTS
• OpenAI: $12.34
• Claude: $37.02
• Twilio: $6.38
• Total: $55.74 ($0.045 per query)

⚠️ ISSUES
• 3 API timeouts (resolved)
• 1 embedding generation failure

🎯 RECOMMENDATIONS
• Add more content on fall protection
• Optimize response time for SMS channel
• Consider caching common queries
```

## Step 9: Business Intelligence

### Customer Insights
- **Which industries use it most?** (based on query patterns)
- **What time do users query?** (peak hours)
- **Geographic distribution** (from phone area codes)
- **Repeat vs new users**

### Product Improvements
- **Identify knowledge gaps** (failed queries)
- **Most requested features** (from support queries)
- **Channel preferences** (SMS vs Voice vs Web)
- **Response quality** (track user satisfaction)

### ROI Metrics for Clients
- **Time saved** (vs manual regulation lookup)
- **Questions answered** per month
- **Compliance issues prevented**
- **Cost per safety incident avoided**

## Implementation Checklist

- [ ] Create analytics tables in Supabase
- [ ] Add logging nodes to n8n workflows
- [ ] Set up basic queries for daily metrics
- [ ] Create simple dashboard or Google Sheet
- [ ] Implement data retention policy
- [ ] Set up weekly email report
- [ ] Configure cost tracking
- [ ] Test all analytics endpoints

---

**Start Simple:**
1. Today: Create tables and add basic logging
2. This week: Build daily summary query
3. Next week: Create dashboard or Google Sheet
4. Month 1: Full analytics with alerts

**Goal:** Data-driven decisions to improve SafetyFirst.AI and demonstrate value to customers!
