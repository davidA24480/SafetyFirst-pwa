# SafetyFirst.AI - Complete System Documentation

## System Overview

SafetyFirst.AI is an AI-powered Australian workplace health and safety assistant that provides instant access to WHS regulations, hazard analysis, and compliance guidance across multiple channels.

## Architecture

### High-Level Components

```
┌─────────────────────────────────────────────────────┐
│                   USER CHANNELS                      │
│  Voice (ElevenLabs) │ SMS/MMS │ WhatsApp │ Web      │
└──────────────┬──────────────────────────────────────┘
               │
               v
┌─────────────────────────────────────────────────────┐
│              API GATEWAY (n8n Cloud)                 │
│  • WHS Query API                                     │
│  • SMS/WhatsApp Handler                              │
│  • Photo Analysis Pipeline                           │
└──────────────┬──────────────────────────────────────┘
               │
        ┌──────┴───────┐
        v              v
┌──────────────┐  ┌──────────────────────┐
│   OpenAI     │  │   Supabase/pgvector  │
│  Embeddings  │  │   • documents table   │
│              │  │   • document_chunks   │
└──────────────┘  │   • vector search     │
                  └──────────────────────┘
        │
        v
┌──────────────────────────────────────────────────────┐
│              Claude AI (Anthropic)                    │
│  • Sonnet 4: Regulation Q&A                          │
│  • Vision: Photo hazard analysis                     │
└──────────────────────────────────────────────────────┘
        │
        v
┌──────────────────────────────────────────────────────┐
│                 RESPONSE DELIVERY                     │
│  Voice │ SMS │ WhatsApp │ Web Chat                   │
└──────────────────────────────────────────────────────┘
```

## Components Detail

### 1. Database (Supabase)

**Project:** gpbncxphtouzgkbtbyst.supabase.co

**Tables:**
- `documents`: Stores metadata about WHS regulations
- `document_chunks`: 506 chunks of regulation text with vector embeddings
- `query_history`: Tracks all user queries (optional)
- `cached_responses`: Stores frequently asked questions (optional)

**Vector Search Function:**
```sql
search_chunks(
    query_embedding vector(1536),
    match_threshold FLOAT DEFAULT 0.7,
    match_count INT DEFAULT 10
)
```

### 2. n8n Workflows

**Base URL:** https://safetyfirstai.app.n8n.cloud

#### Workflow 1: WHS Query API
- **Endpoint:** `/webhook/whs-query`
- **Method:** POST
- **Body:** `{ "query": "user question" }`
- **Flow:**
  1. Receive query
  2. Generate embedding (OpenAI)
  3. Search Supabase vector DB
  4. Build context from top 3 results
  5. Send to Claude Sonnet 4
  6. Return answer with citations

#### Workflow 2: SMS/WhatsApp Handler
- **Endpoint:** `/webhook/sms-whatsapp`
- **Method:** POST (Twilio webhook)
- **Handles:**
  - Text-only messages → WHS query flow
  - MMS with photos → Photo analysis flow

**Photo Analysis Flow:**
1. Parse Twilio webhook
2. Check for media (numMedia > 0)
3. Download photo from Twilio
4. Send to Claude Vision API
5. Get hazard analysis
6. Clean text for SMS
7. Reply via Twilio

### 3. AI Services

#### OpenAI
- **Model:** text-embedding-ada-002
- **Usage:** Text → 1536-dimensional vectors
- **Cost:** $0.0001 per 1K tokens

#### Anthropic Claude
- **Model:** claude-sonnet-4-20250514
- **Usage:** 
  - Text Q&A with regulation context
  - Photo hazard analysis (Vision)
- **API Key:** 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

### 4. Voice Agent (ElevenLabs)

- **Agent:** SafetyFirst AI (Stewart)
- **Voice:** Australian accent
- **Tool:** Calls WHS Query API webhook
- **Phone:** Pending verification (trial account)
- **API Key:** sk_2933bba30f0f456a0eba6759ad9b0a842248573e24da494a

### 5. SMS/MMS (Twilio)

- **US Number:** +1 (765) 885-6366
- **AU Number:** Pending (waiting for ABN)
- **Account SID:** ACc90e01ee919c2e051b30e237ae0fa83a
- **Auth Token:** 61251a57b42cad8850c99e74c6ee6a83
- **Status:** Paid account (no trial restrictions)

### 6. Web Interface

- **Domain:** safetyfirsthq.ai
- **Hosting:** GoDaddy
- **Features:**
  - AI chat interface
  - Photo upload and analysis
  - Voice input (browser microphone)
  - Responsive design

## User Journeys

### Journey 1: Text Query via SMS
```
User → SMS "What height requires fall protection?" 
     → Twilio receives → n8n webhook
     → Parse message → Generate embedding
     → Search Supabase → Get top 3 chunks
     → Send to Claude with context
     → Clean response (remove Markdown, limit 160 chars)
     → Send SMS reply via Twilio
     → User receives answer
```

### Journey 2: Photo Analysis via MMS
```
User → MMS with photo + "What hazards?"
     → Twilio receives → n8n webhook
     → Parse message → Detect media
     → Download photo (Twilio auth)
     → Send to Claude Vision
     → Get hazard analysis
     → Clean for SMS
     → Send SMS reply
     → User receives analysis
```

### Journey 3: Voice Call
```
User → Calls ElevenLabs number
     → Voice agent answers
     → User asks question (speech-to-text)
     → Agent calls n8n WHS Query API
     → Gets answer from Claude
     → Reads answer (text-to-speech)
     → User hears response
```

### Journey 4: Web Chat
```
User → Visits safetyfirsthq.ai
     → Types question in chat
     → JavaScript calls n8n API
     → Same flow as SMS query
     → Response displayed in chat
     → User reads answer
```

## API Documentation

### WHS Query API

**Endpoint:** `POST https://safetyfirstai.app.n8n.cloud/webhook/whs-query`

**Request:**
```json
{
  "query": "What are the requirements for confined spaces?"
}
```

**Response:**
```text
Based on the Australian WHS regulations provided, confined space requirements include:

• Part 4.3 of the Model WHS Regulations specifically addresses confined spaces
• Entry permits and procedures required
• Risk assessment mandatory
• Atmospheric testing and monitoring
• Emergency and rescue procedures must be in place

Reference: Regulation 62(1)(e) and Part 4.3
```

### Twilio SMS Webhook

**Endpoint:** `POST https://safetyfirstai.app.n8n.cloud/webhook/sms-whatsapp`

**Twilio sends:**
```
From: +61433601593
To: +17658856366
Body: What hazards do you see?
NumMedia: 1
MediaUrl0: https://api.twilio.com/...
```

**System responds:** SMS with analysis

## Configuration Files

### Supabase Connection
```javascript
const supabaseUrl = 'https://gpbncxphtouzgkbtbyst.supabase.co';
const supabaseKey = 'sb_secret_JTNTgX97kQ4mDmciHRFShQ_IDqOwxmK';
```

### OpenAI Configuration
```javascript
const openaiKey = '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';
const model = 'text-embedding-ada-002';
```

### Claude Configuration
```javascript
const claudeKey = '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';
const model = 'claude-sonnet-4-20250514';
```

## Monitoring & Maintenance

### Daily Checks
- [ ] n8n workflow executions (check for errors)
- [ ] Twilio message logs
- [ ] ElevenLabs call logs
- [ ] API usage costs

### Weekly Tasks
- [ ] Review query history for common questions
- [ ] Check database performance
- [ ] Update regulations if new ones published
- [ ] Test all channels

### Monthly Tasks
- [ ] Review costs vs budget
- [ ] Update documentation
- [ ] Add new regulations
- [ ] User feedback review

## Troubleshooting

### Issue: SMS not working
1. Check Twilio logs for delivery status
2. Verify webhook URL is correct
3. Check n8n execution logs
4. Verify Twilio credentials in n8n

### Issue: Wrong answers
1. Check which chunks were retrieved
2. Verify embedding quality
3. Adjust match_threshold in search
4. Add more regulation coverage

### Issue: Photo analysis fails
1. Verify numMedia > 0 in webhook
2. Check photo download step
3. Verify Claude Vision API call
4. Check Twilio auth for media download

## Security

### API Keys (Keep Secure)
- Store in environment variables
- Never commit to Git
- Rotate every 90 days
- Use n8n credentials manager

### Data Privacy
- User queries stored in Supabase (optional)
- Photos not stored (analyzed in real-time)
- Comply with Australian Privacy Act
- GDPR considerations for EU users

## Costs (Monthly Estimate)

| Service | Cost |
|---------|------|
| Supabase | $25 |
| OpenAI | $30 |
| Anthropic Claude | $50 |
| ElevenLabs | $100-150 |
| Twilio | $70-100 |
| n8n Cloud | $20 |
| **Total** | **$295-375** |

## Future Enhancements

### Phase 2
- [ ] Mobile app (React Native)
- [ ] Offline mode with cached regulations
- [ ] SWMS document generation
- [ ] User accounts and history
- [ ] Analytics dashboard

### Phase 3
- [ ] Integration with safety management systems
- [ ] Wearable device support
- [ ] Multilingual support
- [ ] Industry-specific modules

## Support

- **Technical Issues:** n8n execution logs
- **API Questions:** Check this documentation
- **Regulation Updates:** Safe Work Australia website
- **Billing:** Check individual service dashboards

---

**Last Updated:** January 20, 2026
**Version:** 1.0
**Maintained by:** David Airoldi, SafetyFirst.AI
